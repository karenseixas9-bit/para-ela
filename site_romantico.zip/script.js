const intro = document.getElementById("intro");
const messageSection = document.getElementById("messageSection");
const openButton = document.getElementById("openButton");
const typedText = document.getElementById("typedText");
const heartsContainer = document.getElementById("hearts-container");

const message = `Talvez existam milhares de formas de dizer o quanto alguém é importante. Mas nenhuma delas parece suficiente quando se trata de você.

Desde que você entrou na minha vida, tudo ficou mais leve. Você tem esse jeito único de estar presente, de fazer questão de demonstrar carinho, de cuidar de mim até nos detalhes mais simples. E, sem perceber, transformou dias comuns em momentos que eu quero guardar para sempre.

O que mais me encanta em você não é apenas o seu sorriso ou a forma como você me faz rir. É a maneira como você permanece ao meu lado quando as coisas ficam difíceis. É o jeito que me acolhe, me escuta, me apoia e faz questão de me lembrar, todos os dias, que eu sou importante.

Você demonstra o seu amor em atitudes, em palavras e em gestos. E eu espero que saiba que cada "eu te amo" que vem de você encontra um lugar especial dentro de mim.

Às vezes eu fico pensando no quanto tive sorte de te encontrar. Você é uma mulher incrível, daquelas que fazem a vida valer mais a pena. Você me inspira a ser uma mulher melhor e me faz acreditar que o amor pode ser leve, verdadeiro e cheio de paz.

No meu coração, você já ocupa um lugar que é só seu. Você é a minha namorada, a mulher que eu escolho todos os dias e com quem eu quero compartilhar a vida. Não é apenas sobre o presente; é sobre todos os sonhos que eu ainda quero viver ao seu lado, todas as memórias que ainda vamos criar e todos os sorrisos que ainda vamos dividir.

Quero continuar vivendo momentos ao seu lado, criando memórias, vencendo desafios juntas, comemorando conquistas e construindo uma história linda. Não importa quanto tempo passe, quero continuar escolhendo você.

Obrigada por existir. Obrigada por cuidar de mim. Obrigada por fazer eu me sentir tão amada, tão segura e tão feliz.

Espero que, quando você estiver lendo isso, consiga sentir um pouquinho de tudo o que eu sinto por você. Porque, por mais que as palavras tentem explicar, elas nunca serão suficientes para descrever o tamanho do amor, da admiração e da gratidão que tenho por ter você na minha vida.

Eu te amo hoje, amanhã e em todos os dias que ainda virão. E, se depender de mim, essa será apenas a primeira página da história mais bonita que nós duas vamos escrever juntas.

Com todo o meu amor,

Sua futura esposa. ❤️`;

let typingStarted = false;

openButton.addEventListener("click", () => {
  if (typingStarted) return;
  typingStarted = true;

  createHeartBurst(45);
  intro.classList.remove("active");
  messageSection.classList.add("active");
  window.scrollTo({ top: 0, behavior: "smooth" });

  setTimeout(() => {
    typeWriter(message, 0);
    startHeartRain();
  }, 700);
});

function typeWriter(text, index) {
  if (index < text.length) {
    typedText.textContent += text.charAt(index);

    const currentChar = text.charAt(index);
    const delay =
      currentChar === "\n" ? 120 :
      [".", "!", "?"].includes(currentChar) ? 90 :
      [",", ";", ":"].includes(currentChar) ? 45 :
      18;

    setTimeout(() => typeWriter(text, index + 1), delay);
  }
}

function createHeart() {
  const heart = document.createElement("span");
  const symbols = ["❤️", "💗", "💖", "💕", "💘"];
  heart.className = "heart";
  heart.textContent = symbols[Math.floor(Math.random() * symbols.length)];

  const size = 16 + Math.random() * 22;
  const duration = 4 + Math.random() * 4;
  const drift = `${-110 + Math.random() * 220}px`;

  heart.style.left = `${Math.random() * 100}vw`;
  heart.style.fontSize = `${size}px`;
  heart.style.animationDuration = `${duration}s`;
  heart.style.setProperty("--drift", drift);

  heartsContainer.appendChild(heart);
  setTimeout(() => heart.remove(), duration * 1000);
}

function createHeartBurst(amount) {
  for (let i = 0; i < amount; i++) {
    setTimeout(createHeart, i * 35);
  }
}

function startHeartRain() {
  setInterval(createHeart, 420);
}
